import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cooperative_navigation_safety/src/core/models/beacon_packet.dart';
import 'package:cooperative_navigation_safety/src/core/models/sensor_data.dart';
import 'package:cooperative_navigation_safety/src/core/models/collision_alert.dart';
import 'package:cooperative_navigation_safety/src/services/sensor_service.dart';
import 'package:cooperative_navigation_safety/src/services/nearby_service.dart';
import 'package:cooperative_navigation_safety/src/services/collision_engine.dart';

// Services
final sensorServiceProvider = Provider<SensorService>((ref) => SensorService());
final nearbyServiceProvider = Provider<NearbyService>((ref) => NearbyService());
final collisionEngineProvider = Provider<CollisionEngine>((ref) => CollisionEngine());

// App state
final appStateProvider = StateNotifierProvider<AppStateNotifier, AppState>((ref) {
  return AppStateNotifier(ref);
});

class AppState {
  final bool isSystemRunning;
  final bool hasPermissions;
  final String mode;
  final String? error;
  
  const AppState({
    this.isSystemRunning = false,
    this.hasPermissions = false,
    this.mode = 'normal',
    this.error,
  });
  
  AppState copyWith({
    bool? isSystemRunning,
    bool? hasPermissions,
    String? mode,
    String? error,
  }) {
    return AppState(
      isSystemRunning: isSystemRunning ?? this.isSystemRunning,
      hasPermissions: hasPermissions ?? this.hasPermissions,
      mode: mode ?? this.mode,
      error: error ?? this.error,
    );
  }
}

class AppStateNotifier extends StateNotifier<AppState> {
  final Ref _ref;
  
  AppStateNotifier(this._ref) : super(const AppState());
  
  void startSystem() {
    state = state.copyWith(isSystemRunning: true, error: null);
  }
  
  void stopSystem() {
    state = state.copyWith(isSystemRunning: false);
  }
  
  void setPermissionsGranted() {
    state = state.copyWith(hasPermissions: true);
  }
  
  void setMode(String mode) {
    state = state.copyWith(mode: mode);
  }
  
  void setError(String error) {
    state = state.copyWith(error: error);
  }
  
  void clearError() {
    state = state.copyWith(error: null);
  }
}

// Sensor data stream
final sensorDataStreamProvider = StreamProvider<SensorData>((ref) {
  final sensorService = ref.watch(sensorServiceProvider);
  return sensorService.sensorStream;
});

// Nearby beacons stream
final beaconStreamProvider = StreamProvider<BeaconPacket>((ref) {
  final nearbyService = ref.watch(nearbyServiceProvider);
  return nearbyService.beaconStream;
});

// Current location provider
final currentLocationProvider = Provider<BeaconPacket?>((ref) {
  final sensorData = ref.watch(sensorDataStreamProvider);
  final appState = ref.watch(appStateProvider);
  
  return sensorData.when(
    data: (data) {
      if (!appState.isSystemRunning) return null;
      
      // This would be populated with actual location data
      // For now, returning a placeholder
      return null;
    },
    loading: () => null,
    error: (_, __) => null,
  );
});

// Peer beacons provider
final peerBeaconsProvider = StateProvider<List<BeaconPacket>>((ref) => []);

// Collision alerts provider
final collisionAlertsProvider = Provider<List<CollisionAlert>>((ref) {
  final currentLocation = ref.watch(currentLocationProvider);
  final peerBeacons = ref.watch(peerBeaconsProvider);
  final collisionEngine = ref.watch(collisionEngineProvider);
  
  if (currentLocation == null || peerBeacons.isEmpty) {
    return [];
  }
  
  return collisionEngine.processMultiplePeers(currentLocation, peerBeacons);
});

// Critical alert provider
final criticalAlertProvider = Provider<CollisionAlert?>((ref) {
  final alerts = ref.watch(collisionAlertsProvider);
  return alerts.isEmpty ? null : alerts.first;
});

// System coordinator
final systemCoordinatorProvider = Provider<SystemCoordinator>((ref) {
  return SystemCoordinator(ref);
});

class SystemCoordinator {
  final Ref _ref;
  StreamSubscription? _sensorSubscription;
  StreamSubscription? _beaconSubscription;
  
  SystemCoordinator(this._ref);
  
  Future<void> initialize() async {
    try {
      final sensorService = _ref.read(sensorServiceProvider);
      final nearbyService = _ref.read(nearbyServiceProvider);
      
      await sensorService.initialize();
      await nearbyService.initialize();
      
      _ref.read(appStateProvider.notifier).setPermissionsGranted();
    } catch (e) {
      _ref.read(appStateProvider.notifier).setError('Failed to initialize: $e');
      rethrow;
    }
  }
  
  void startSystem() {
    final sensorService = _ref.read(sensorServiceProvider);
    final nearbyService = _ref.read(nearbyServiceProvider);
    final appState = _ref.read(appStateProvider);
    
    if (!appState.hasPermissions) {
      _ref.read(appStateProvider.notifier).setError('Permissions not granted');
      return;
    }
    
    // Start sensors
    sensorService.startSensors();
    
    // Start nearby connections
    nearbyService.startNearby();
    
    // Setup beacon timer
    nearbyService.startBeaconTimer(() => _generateBeacon());
    
    // Setup subscriptions
    _setupSubscriptions();
    
    _ref.read(appStateProvider.notifier).startSystem();
  }
  
  void stopSystem() {
    final sensorService = _ref.read(sensorServiceProvider);
    final nearbyService = _ref.read(nearbyServiceProvider);
    
    _sensorSubscription?.cancel();
    _beaconSubscription?.cancel();
    
    sensorService.stopSensors();
    nearbyService.stopNearby();
    
    _ref.read(appStateProvider.notifier).stopSystem();
    _ref.read(peerBeaconsProvider.notifier).state = [];
  }
  
  void _setupSubscriptions() {
    final sensorService = _ref.read(sensorServiceProvider);
    final nearbyService = _ref.read(nearbyServiceProvider);
    
    // Listen to sensor data
    _sensorSubscription = sensorService.sensorStream.listen((sensorData) {
      // Process sensor data and update current location
      // This would integrate with the beacon generation
    });
    
    // Listen to incoming beacons
    _beaconSubscription = nearbyService.beaconStream.listen((beacon) {
      final currentPeers = _ref.read(peerBeaconsProvider);
      
      // Update or add peer beacon
      final updatedPeers = currentPeers.where((p) => p.ephemeralId != beacon.ephemeralId).toList();
      updatedPeers.add(beacon);
      
      // Remove stale beacons (older than 5 seconds)
      final now = DateTime.now();
      final freshPeers = updatedPeers.where((p) => 
        now.difference(p.timestamp).inSeconds < 5
      ).toList();
      
      _ref.read(peerBeaconsProvider.notifier).state = freshPeers;
    });
  }
  
  BeaconPacket _generateBeacon() {
    final appState = _ref.read(appStateProvider);
    final sensorData = _ref.read(sensorDataStreamProvider);
    
    // This would integrate real sensor data
    return BeaconPacket(
      type: 'beacon',
      ephemeralId: 'device_${DateTime.now().millisecondsSinceEpoch}',
      timestamp: DateTime.now(),
      latitude: 0.0, // Would be from GPS
      longitude: 0.0, // Would be from GPS
      altitude: 0.0,
      speed: 0.0,
      heading: 0.0,
      velocityX: 0.0,
      velocityY: 0.0,
      accuracy: 5.0,
      battery: 100,
      mode: appState.mode,
    );
  }
}
class SensorData {
  final DateTime timestamp;
  final double accelerometerX;
  final double accelerometerY;
  final double accelerometerZ;
  final double gyroscopeX;
  final double gyroscopeY;
  final double gyroscopeZ;
  final double magnetometerX;
  final double magnetometerY;
  final double magnetometerZ;
  final double? heading;

  SensorData({
    required this.timestamp,
    required this.accelerometerX,
    required this.accelerometerY,
    required this.accelerometerZ,
    required this.gyroscopeX,
    required this.gyroscopeY,
    required this.gyroscopeZ,
    required this.magnetometerX,
    required this.magnetometerY,
    required this.magnetometerZ,
    this.heading,
  });

  double get totalAcceleration => 
      (accelerometerX * accelerometerX + accelerometerY * accelerometerY + accelerometerZ * accelerometerZ).sqrt();

  double get totalGyroscope => 
      (gyroscopeX * gyroscopeX + gyroscopeY * gyroscopeY + gyroscopeZ * gyroscopeZ).sqrt();

  bool detectSuddenDeceleration({double threshold = 15.0}) {
    return totalAcceleration > threshold;
  }

  bool detectAbnormalIMUSpike({double threshold = 20.0}) {
    return totalGyroscope > threshold || totalAcceleration > threshold;
  }

  SensorData copyWith({
    DateTime? timestamp,
    double? accelerometerX,
    double? accelerometerY,
    double? accelerometerZ,
    double? gyroscopeX,
    double? gyroscopeY,
    double? gyroscopeZ,
    double? magnetometerX,
    double? magnetometerY,
    double? magnetometerZ,
    double? heading,
  }) {
    return SensorData(
      timestamp: timestamp ?? this.timestamp,
      accelerometerX: accelerometerX ?? this.accelerometerX,
      accelerometerY: accelerometerY ?? this.accelerometerY,
      accelerometerZ: accelerometerZ ?? this.accelerometerZ,
      gyroscopeX: gyroscopeX ?? this.gyroscopeX,
      gyroscopeY: gyroscopeY ?? this.gyroscopeY,
      gyroscopeZ: gyroscopeZ ?? this.gyroscopeZ,
      magnetometerX: magnetometerX ?? this.magnetometerX,
      magnetometerY: magnetometerY ?? this.magnetometerY,
      magnetometerZ: magnetometerZ ?? this.magnetometerZ,
      heading: heading ?? this.heading,
    );
  }
}